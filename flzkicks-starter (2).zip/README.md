# FLZKicks — Starter React + Vite + Tailwind Demo

This is a small demo storefront for **FLZKicks** (sneaker resell demo). It includes:
- React + Vite setup
- Tailwind CSS
- Demo product list, cart drawer, and fake checkout modal

## Run locally

1. Install dependencies:
   ```
   npm install
   ```
2. Run dev server:
   ```
   npm run dev
   ```
3. Open http://localhost:5173

## Deploy to Vercel

Recommended way (connect a Git provider):
1. Create a GitHub repository and push this project.
2. Go to https://vercel.com and sign in.
3. Click "New Project" → Import from GitHub → select your repo.
4. Accept the defaults (Framework: Vite) and click "Deploy".

Or deploy from your local machine by following Vercel's docs (use `vercel` CLI) or upload to a Git provider.

## Notes
- This demo does **not** include real authentication or payment. Replace fakeCheckout with a real payment integration (Stripe, PayPal, etc.) before using for real sales.
- Images are hot-linked from Unsplash for demo purposes.