import React, { useState, useMemo } from "react";

export default function App() {
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  const products = [
    { name: "Jordan 4 Black Cat", price: 280, image: "https://images.unsplash.com/photo-1606813902913-0e1d3f1b3c0d?q=80&w=1200&auto=format&fit=crop" },
    { name: "Yeezy 350 Zebra", price: 240, image: "https://images.unsplash.com/photo-1528701800489-20be3c3e1e7a?q=80&w=1200&auto=format&fit=crop" },
    { name: "Jordan 1 Retro", price: 170, image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1200&auto=format&fit=crop" },
  ];

  const filteredProducts = useMemo(() => {
    if (!query) return products;
    return products.filter(p => p.name.toLowerCase().includes(query.toLowerCase()));
  }, [query]);

  const addToCart = (product) => {
    const key = `${product.name}-${Date.now()}`;
    setCart(prev => [...prev, { key, product, qty: 1, size: "10" }]);
    setCartOpen(true);
  };

  const removeFromCart = (key) => {
    setCart(prev => prev.filter(item => item.key !== key));
  };

  const updateQty = (key, qty) => {
    if (qty < 1) return;
    setCart(prev =>
      prev.map(item => item.key === key ? { ...item, qty } : item)
    );
  };

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.qty, 0);
  const shipping = subtotal > 0 ? 15 : 0;
  const tax = subtotal * 0.07;
  const total = subtotal + shipping + tax;

  const fakeCheckout = () => {
    alert("✅ Demo checkout complete! (No real payment processed)");
    setCheckoutOpen(false);
    setCart([]);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-black text-white py-4">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-400">FLZKicks</h1>
          <button onClick={() => setCartOpen(true)} className="bg-blue-500 px-3 py-1 rounded">Cart ({cart.length})</button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 flex">
        <aside className="w-64 pr-6 border-r">
          <h2 className="font-semibold mb-2">Filter by Model</h2>
          <ul className="space-y-2">
            <li><button className="underline text-left" onClick={() => setQuery('')}>Show All</button></li>
            <li><button className="underline text-left" onClick={() => setQuery('Black Cat')}>Show Black Cat</button></li>
            <li><button className="underline text-left" onClick={() => setQuery('Yeezy')}>Show Yeezy</button></li>
          </ul>
        </aside>

        <section className="flex-1 pl-6">
          <h2 className="text-2xl font-bold mb-4">Shop Sneakers</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {filteredProducts.map((p) => (
              <div key={p.name} className="bg-white rounded-xl shadow p-3 hover:shadow-lg transition">
                <img src={p.image} alt={p.name} className="w-full h-48 object-cover rounded" />
                <div className="mt-2">
                  <h3 className="font-semibold">{p.name}</h3>
                  <p className="text-gray-600">${p.price}</p>
                  <button
                    className="mt-2 w-full bg-blue-500 text-white rounded py-2"
                    onClick={() => addToCart(p)}
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Cart drawer/modal */}
      {cartOpen && (
        <div className="fixed right-6 top-20 w-96 bg-white rounded shadow-lg p-4 z-50">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold">Your Cart</h3>
            <div className="text-sm text-gray-500">{cart.length} items</div>
          </div>

          <div className="space-y-3 max-h-72 overflow-auto">
            {cart.length === 0 && <div className="text-gray-500">Cart is empty</div>}
            {cart.map(item => (
              <div key={item.key} className="flex items-center gap-3">
                <img src={item.product.image} alt={item.product.name} className="w-14 h-14 object-cover rounded" />
                <div className="flex-1">
                  <div className="font-semibold text-sm">{item.product.name}</div>
                  <div className="text-xs text-gray-500">Size: {item.size}</div>
                  <div className="text-sm">${item.product.price} x {item.qty}</div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <input type="number" className="w-14 px-1 py-0.5 border rounded text-sm"
                    value={item.qty} min="1"
                    onChange={e => updateQty(item.key, Number(e.target.value))} />
                  <button className="text-xs text-red-600" onClick={() => removeFromCart(item.key)}>Remove</button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 border-t pt-3">
            <div className="flex justify-between text-sm mb-1"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between text-sm mb-1"><span>Shipping</span><span>${shipping.toFixed(2)}</span></div>
            <div className="flex justify-between text-sm mb-1"><span>Tax</span><span>${tax.toFixed(2)}</span></div>
            <div className="flex justify-between font-bold text-lg mt-2"><span>Total</span><span>${total.toFixed(2)}</span></div>

            <div className="mt-3 flex gap-2">
              <button onClick={() => setCheckoutOpen(true)} className="flex-1 px-3 py-2 bg-green-600 text-white rounded">Checkout</button>
              <button onClick={() => setCartOpen(false)} className="px-3 py-2 border rounded">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* Checkout modal */}
      {checkoutOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded shadow-lg w-full max-w-md">
            <h3 className="font-bold text-lg mb-2">Checkout (Demo)</h3>
            <p className="text-sm text-gray-600 mb-4">
              This demo simulates a checkout. Replace this with a real payment integration
              (Stripe, PayPal, Cash App API, etc.) before going live.
            </p>

            <label className="block text-sm">Name</label>
            <input className="w-full px-3 py-2 border rounded mb-2" placeholder="John Doe" />
            <label className="block text-sm">Email</label>
            <input className="w-full px-3 py-2 border rounded mb-2" placeholder="you@example.com" />

            <div className="flex gap-2 mt-3">
              <button onClick={fakeCheckout} className="flex-1 px-3 py-2 bg-black text-white rounded">
                Pay ${total.toFixed(2)}
              </button>
              <button onClick={() => setCheckoutOpen(false)} className="px-3 py-2 border rounded">Cancel</button>
            </div>
          </div>
        </div>
      )}

      <footer className="bg-white border-t py-4 mt-10">
        <div className="max-w-6xl mx-auto px-4 text-sm text-gray-600">
          © {new Date().getFullYear()} FLZKicks — Demo store. Not for real sales.
        </div>
      </footer>
    </div>
  );
}